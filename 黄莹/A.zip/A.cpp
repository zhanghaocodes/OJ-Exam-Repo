#include <iostream>
using namespace std;

int main()
{
	int N;
	cin >> N;
	int one = 0;
	int two = 0;
	for (int i = 0; i < N; i++)
	{
		int n;
		cin >> n;
		if (n % 2 == 0)
		{
			two++;
		}
		else
		{
			one++;
		}
	}
	cout << (one < two ? one : two);
}