#include <iostream>
#include <queue>
#include <map>
#include <string>
using namespace std;

int main()
{
	int N;
	cin >> N;
	char c;
	char pre;

	int times[26][26] = { { 0 } };
	cin >> pre;
	
	for (int i = 1; i < N; i++)
	{
		cin >> c;
		times[pre - 'A'][c - 'A']++;
		pre = c;
	}
	int maxi = -1;
	int maxj = -1;
	int maxn = -1;
	for (int i=0;i<26;i++)
		for (int j = 0; j < 26; j++)
		{
			if (times[i][j] > maxn)
			{
				maxn = times[i][j];
				maxi = i;
				maxj = j;
			}
		}
	cout << (char)(maxi + 'A') << (char)(maxj + 'A');
	getchar();
	getchar();
}