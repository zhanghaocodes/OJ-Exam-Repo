#include <iostream>
using namespace std;

int main()
{
	int t;
	cin >> t;
	int row[9] = { 0,1,2,3,4,5,6,7,8 };
	int col[9] = { 0,3,6,1,4,7,2,5,8 };
	for (int i = 0; i < t; i++)
	{
		int sudoku[9][9] = { 0 };
		for (int j=0;j<9;j++)
			for (int k = 0; k < 9; k++)
			{
				char num;
				cin >> num;
				sudoku[j][k] = num - '0';
			}
		for (int j = 0; j < 9; j++)
		{
			if (sudoku[row[j]][col[j]] == 3)
			{
				sudoku[row[j]][col[j]] = 8;
			}
			else
			{
				sudoku[row[j]][col[j]] = 3;
			}
		}
		for (int j = 0; j < 9; j++)
		{
			for (int k = 0; k < 9; k++)
			{
				cout<<sudoku[j][k];
			}
			cout << endl;
		}
	}
}