#include <iostream>
#include <string>
#include <vector>
#include <set>
using namespace std;

int main()
{
	int n, m;
	cin >> n >> m;
	int* raw = new int[n];
	for (int i = 0; i < n; i++)
	{
		cin >> raw[i];
	}
	for (int i = 0; i < n; i++)
	{
		int *num = new int[n];
		for (int j = 0; j < n; j++)
		{
			num[j] = j + 1;
		}
		int tmp = num[i];
		for (int j = i; j > 0; j--)
		{
			num[j] = num[j - 1];
		}
		num[0] = tmp;
		string s;
		for (int j = 0; j < n; j++)
		{
			s.push_back(num[j] + '0');
		}

		int* pos = new int[n];
		for (int j = 0; j < n; j++)
		{
			int fi = raw[j];
			int ps = s.find((fi+'0'));
			pos[j] = pos[ps + 1];
		}
		int sum = 0;
		for (int j = 0; j < m-1; j++)
		{
			sum += abs(pos[j] - pos[j + 1]);
		}
		cout << sum << " ";
	}
	getchar();
	getchar();
	getchar();
	getchar();
	getchar();
}