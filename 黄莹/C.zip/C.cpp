#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
	int N;
	cin >> N;
	for (int i = 0; i < N; i++)
	{
		int n;
		cin >> n;
		int status, maxn;
		long long sum = 0;
		int num;
		cin >> num;
		maxn = num;
		if (num > 0)
		{
			status = 0;
		}
		else
		{
			status = -1;
		}
		for (int j = 1; j < n; j++)
		{
			cin >> num;
			if (num > 0 && status == 0)
			{
				maxn = max(num, maxn);
			}
			else if (num < 0 && status == -1)
			{
				maxn = max(num, maxn);
			}
			else
			{
				sum += maxn;
				maxn = num;
				if (num > 0)
				{
					status = 0;
				}
				else
				{
					status = -1;
				}
			}
		}
		sum += maxn;

		cout << sum << endl;
	}
}